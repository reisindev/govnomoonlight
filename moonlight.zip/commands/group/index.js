const { stripIndents } = require('common-tags');
const { Utils } = require('@rus-anonym/utils');

const rusAnonymUtils = new Utils();

function saveUsers() {
  return writeFile(resolve('json', 'users.json'), JSON.stringify(users, null, '\t'), 'utf-8');
}

const giveLimit = [0, 100_000, 500_000, 5_000_000, 10_000_000, 20_000_000, 25_000_000, 35_000_000, 50_000_000, 70_000_000, 150_000_000, 200_000_000];

module.exports.eval = {
  pattern: /^(?:\!|eval)(?:\s(?<code>.+))$/is,
  handler: async (context, { bot }, { users: double }) => {
    const { code } = context.$match.groups;

    const admins = await context['api'].groups.getMembers({
      filter: 'managers',
      group_id: context.$groupId,
    });

    const adminsAndCreatorIds = admins.items.filter((item) => item.id && (item.role === 'administrator' || item.role === 'creator')).map((item) => item.id);

    if (!adminsAndCreatorIds.includes(context.senderId)) {
      return bot('доступ запрещён.');
    }

    const start = Date.now();

    let formatCode = code.replace(/^msg/ig, 'context').replace(/^chat/ig, 'context.chat');

    if (/^context\.us(er)?/ig.test(formatCode)) {
      formatCode = formatCode.replace(/^context\.us(er)?/ig, 'double.find(user => user.vkId === (context.hasForwards ? context.forwards?.[0]?.senderId : context.replyMessage?.senderId ?? context.senderId))');
    }

    try {
      const result = await eval(`async () => {
        if (${/^context\.us(er)?/ig.test(formatCode)}) {
          ${formatCode}

          await saveUsers()

          return ${formatCode}
        }

        ${formatCode.includes('return') ? formatCode : `return ${formatCode}`}
      }`)();

      const typeResult = rusAnonymUtils.typeof(result) === 'object' ? result.constructor.name : rusAnonymUtils.typeof(result);

      return context.send(stripIndents`
        🆚 Итог: ${JSON.stringify(result, null, '&#4448;')}
        📕 Тип: ${typeResult}
        
        ✅ Код выполнен за ${Date.now() - start} мс.
      `);
    } catch (error) {
      return bot(`возникла ошибка - ${(error).toString()}`);
    }
  }
}