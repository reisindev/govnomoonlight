

module.exports.bank = require('./bank');
module.exports.bet = require('./bet');
module.exports.doubleCreate = require('./double-create');
module.exports.gift = require('./gift');
module.exports.doubleDelete = require('./double-delete');
