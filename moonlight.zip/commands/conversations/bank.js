const utils = require('../../utils');

module.exports = {
  pattern: /^(?:банк)$/i,
  handler: (context, { bot }) => {
    if (!context.isChat || !context.chat.double) {
      return;
    }

    const game = context.chat.games[context.chat.games.length - 1];

    if (!game.users.length) {
      return bot(`в этом раунде еще никто не поставил.
  
        [🎮] Хеш игры: ${game.hash}
  
        [⌚] Ожидаем ставок...
      `);
    }

    const textArray = [
      {
        factor: 2,
        text: 'Ставки на x2:',
        users: []
      },
      {
        factor: 3,
        text: 'Ставки на x3:',
        users: []
      },
      {
        factor: 5,
        text: 'Ставки на x5:',
        users: []
      },
      {
        factor: 10,
        text: 'Ставки на х10:',
        users: []
      },
      {
        factor: 50,
        text: 'Ставки на x50:',
        users: []
      }
    ];

    context.state = {
      balance: 0
    }

    for (const user of game.users) {
      const text = textArray.find(({ factor }) => factor === user.factor);

      text.users.push(user);
    }

    for (const user of game.users) {
      context.state.balance += user.balance;
    }

    const newTextArray = textArray.filter(item => item.users.length);

    return bot(`всего поставлено: ${utils.sp(context.state.balance)} MB
      ${newTextArray.map((item) => `
        ${item.text}
        ${item.users
        .map(user => `${user.mention ? `@id${user.vkId} (${user.name})` : user.name} - ${utils.sp(user.balance)} MB`)
        .join('\n')}
      `).join('\n')}
  
      🎮 Хеш игры: ${game.hash}
  
      ⌛ До конца раунда: ${context.chat.timers.game} сек.
    `);
  },
  isPayload: true,
  payload: /^(?:bank)$/i
}