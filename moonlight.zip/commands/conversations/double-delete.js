

const { Keyboard } = require('vk-io');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:дабл удалить)$/i,
  handler: async (context, { bot }) => {
    if (!context.isChat || !context.chat.double) {
      return;
    }

    const user = await utils.getMemberConversation(context);

    if (!user.is_admin && !user.is_owner) {
      return bot('Вы не можете перевести режим "Double" в беседу, поскольку это могут сделать только администраторы и/или создатель чата!');
    }

    if (/^дабл удалить$/i.test(context.$match[0])) {
      if (!context.chat.code) {
        context.chat.code = utils.getRandomHax(4);
      }

      return bot(`Вы уверены, что хотите снести Double в данном чате?`, {
        keyboard: Keyboard.builder()
          .textButton({
            label: '🛑 Уверен',
            payload: `double-delete ${context.chat.code}`,
            color: 'negative',
          })
          .inline()
      });
    }

    context.chat.games = [];
    context.chat.game = false;
    context.chat.double = false;
    context.chat.code = null;
    context.chat.timers.game = 0;
    context.chat.start = false;

    await context.send('Очищаю клавиатуру...', { keyboard: Keyboard.keyboard([]) });

    return bot('режим "Double" был успешно снесён с данного чата.')
  },
  isPayload: true,
  payload: /^(?:double-delete)(?:\s(?<code>.+))$/i,
}
