

const { Keyboard } = require('vk-io');

const utils = require('../../utils');

const factors = [2, 3, 5, 10, 50];

module.exports = {
  pattern: /^(?:ставка\s)?(?<factor>\d+)(?:\s(?<count>(?:[0-9\.]+[kкmм]*|вс[её]|all|в[оа]банк)))?$/i,
  handler: async (context, { bot }) => {
    if (!context.isChat) {
      return bot('данная команда работает только в беседе.');
    }

    if (context.isChat && !context.chat.double) {
      return bot('Вы не можете использовать данную команду пока не переведете беседу в режим "Double".');
    }

    if (!context.chat.games[context.chat.games.length - 1].bet) {
      return bot('время для принятия ставок закончилось, ожидайте следующего раунда.');
    }

    const { factor, count } = context.$match.groups;

    if (!factors.includes(parseInt(factor))) {
      return bot('доступные коэффициенты для ставки: х2, х3, х5, x10, х50');
    }

    const formatCount = utils.parse2Int((count || '0').replace(/вс[её]|all|в[ао]банк/g, context.user.balance.toString()));

    if (!formatCount) {
      return bot(`нажмите кнопку ИЛИ введите команду: "${factor} [кол-во]"`, {
        keyboard: Keyboard.builder()
          .textButton({
            label: `x${factor} ${(context.user.lastBet || context.user.balance / 2)}`,
            payload: `bet ${factor} ${context.user.lastBet || context.user.balance / 2}`,
            color: 'secondary'
          })
          .textButton({
            label: `x${factor} ${((context.user.lastBet || context.user.balance) * 2)}`,
            payload: `bet ${factor} ${(context.user.lastBet || context.user.balance) * 2}`,
            color: 'secondary'
          })
          .textButton({
            label: `x${factor} ${context.user.balance}`,
            payload: `bet ${factor} all`,
            color: 'secondary'
          })
          .inline()
      })
    }

    if (formatCount > context.user.balance) {
      return bot('у Вас недостаточно средств на балансе!');
    }

    const { users: usersList } = context.chat.games[context.chat.games.length - 1];
    const user = usersList.find(user => user.vkId === context.senderId && user.factor === parseInt(factor));

    if (user) {
      user.balance += formatCount;
    } else {
      usersList.push({
        vkId: context.senderId,
        name: context.user.name,
        factor: parseInt(factor),
        balance: formatCount,
        mention: context.user.settings.mention,
      });
    }

    context.user.balance -= formatCount;
    context.user.lastBet = formatCount;

    return bot(`успешная ставка ${utils.sp(formatCount)} MB на коэффициент x${factor}`);
  },
  isPayload: true,
  payload: /^(?:bet)(?:\s(?<factor>\d+))(?:\s(?<count>(?:[0-9\.]+[kкmм]*|all)))?$/i,
}