const { Keyboard } = require('vk-io');

const utils = require('../../utils');

const keyboard = Keyboard.builder()
  .textButton({
    label: '💰 Банк',
    payload: 'bank',
    color: 'positive'
  })
  .textButton({
    label: '📂 Профиль',
    payload: 'profile',
    color: 'positive'
  })
  .textButton({
    label: '💵 Баланс',
    payload: 'balance',
    color: 'positive'
  })
  .row()
  .textButton({
    label: '2⃣ x2',
    payload: 'bet 2',
    color: 'primary'
  })
  .textButton({
    label: '3⃣ x3',
    payload: 'bet 3',
    color: 'primary'
  })
  .textButton({
    label: '5⃣ x5',
    payload: 'bet 5',
    color: 'primary'
  })
  .row()
  .textButton({
    label: '🔟 x10',
    payload: 'bet 10',
    color: 'positive'
  })
  .textButton({
    label: '🔯 x50',
    payload: 'bet 50',
    color: 'positive'
  })
  .row()
  .textButton({
    label: '👑 Рейтинг',
    payload: 'ratings',
    color: 'negative'
  })
  .textButton({
    label: '🎁 Бонус',
    payload: 'bonus',
    color: 'secondary'
  })
  .textButton({
    label: '🎈 Донат',
    payload: 'donate',
    color: 'secondary'
  })
  .oneTime(false);

module.exports = {
  pattern: /^(?:дабл создать)(?:\s(?<code>.+))?$/i,
  handler: async (context, { bot }) => {
    if (!context.isChat || context.chat.double) {
      return;
    }

    const user = await utils.getMemberConversation(context);

    if (!user.is_admin && !user.is_owner) {
      return bot('Вы не можете перевести беседу в режим "Double", поскольку это могут сделать только администраторы и/или создатель чата!');
    }

    const { code } = context.$match.groups;

    if (!code) {
      if (!context.chat.code) {
        context.chat.code = utils.getRandomHax(4);
      }

      return bot(`Вы уверены, что хотите перевести эту беседу в режим "Double"?
        💵 Стоимость: 250.000 SB
        ✅ Если уверены введите "Дабл создать ${context.chat.code}" или нажмите на кнопку для перевода беседы в режим "Double"
      `, {
        keyboard: Keyboard.builder()
          .textButton({
            label: '✅ Создать дабл',
            payload: `double-create ${context.chat.code}`,
            color: 'primary',
          })
          .inline()
      });
    }

    if (code !== context.chat.code) {
      return bot('введённый Вами код не соответствует коду который должен разрешать перевод беседы в режим "Double"!');
    }

    if (context.user.balance < 250_000) {
      return bot('у Вас недостаточно SB для перевода беседы в режим "Double"!');
    }

    context.chat.code = null
    context.chat.double = true;
    context.chat.game = false;
    context.chat.timers.game = 60;
    context.chat.start = false;

    context.user.balance -= 250_000;

    await context.send('Обновляю клавиатуру...', { keyboard });

    return bot(`чат успешно был переведён в режим "Double"`);
  },
  isPayload: true,
  payload: /^(?:double-create)(?:\s(?<code>.+))$/i,
}