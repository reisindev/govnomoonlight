

const { Keyboard } = require('vk-io');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:подарок|беседа подарок)$/i,
  handler: async (context, { bot }) => {
    if (!context.isChat) {
      return bot('данная команда доступна только в чате!');
    }

    if (context.chat.timers.gift > Date.now()) {
      return bot(`в этой беседе уже забирали подарок!
        ⏰ Подождите ещё ${utils.dateFormat(context.chat.timers.gift)}
      `, {
        keyboard: Keyboard.builder()
          .textButton({
            label: '🎁 Подарок',
            payload: 'gift',
            color: context.chat.timers.gift > Date.now() ? 'negative' : 'positive'
          })
          .inline()
      });
    }

    const balance = utils.getRandomInt(5000);

    context.chat.timers.gift = Date.now() + 60_000 * 10;

    context.user.balance += balance;

    return bot(`Вы получили подарок в размере ${utils.sp(balance)} SB
      🚀 Следующий подарок будет через ${utils.dateFormat(context.chat.timers.gift)}
    `, {
      attachment: ['photo-215392582_457239022', 'photo-160021944_456240460']
    });
  },
  isPayload: true,
  payload: /^(?:gift)$/i,
}
