const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:\!бан\s?репорта?)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('данного игрока нет в базе данных.');
    }

    if (user.vkId === context.senderId) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (user.block.reports) {
      return bot(`игроку "@id${user.vkId} (${user.name})" уже была ранее выдана блокировка репорта.`);
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    user.block.reports = true;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / БЛОКИРОВКА РЕПОРТА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" заблокировал Вам возможность писать репорты.
      `, {
        peer_id: user.vkId,
      });
    }

    await context.send(stripIndents`[ЛОГИ / БЛОКИРОВКА РЕПОРТА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" заблокировал возможность писать репорты игроку "@id${user.vkId} (${user.name})"
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID)
    });


    return bot(`Вы заблокировали репорт игроку "@id${user.vkId} (${user.name})"`);
  },
  isPayload: true,
  payload: /^(?:ban-report)(?:\s(?<id>\d+))$/i,
  isRole: true,
  role: 8
}