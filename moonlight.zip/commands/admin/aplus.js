const actionState = require('./actionState');

module.exports = {
  pattern: /^(?:\+акция)$/i,
  handler: async (context, { bot }) => {
    if (actionState.get()) {
      return bot('Акция уже запущена.');
    }

    actionState.set(true);
    await bot('Акция запущена!');
    // Код запуска акции
  },
  isRole: true,
  role: 8
}
