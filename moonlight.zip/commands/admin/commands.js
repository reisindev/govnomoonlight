const utils = require('../../utils');

const commands = [
  {
    command: '!Банакк [id/link] [время] [причина]',
    level: 5,
  },
  {
    command: '!Кик [id/link]',
    level: 5,
  },
  {
    command: 'Выдать [кол-во]',
    level: 1,
  },
  {
    command: 'Состав',
    level: 5,
  },
  {
    command: 'Атоп',
    level: 8,
  },
  {
    command: 'Выдать [id/link] [кол-во]',
    level: 8,
  },
  {
    command: 'Забрать [id/link] [кол-во]',
    level: 8,
  },
  {
    command: '!Разбанакк [id/link]',
    level: 8,
  },
  {
    command: '!Бантоп [id/link]',
    level: 8,
  },
  {
    command: '!Разбантоп [id/link]]',
    level: 8,
  },
  {
    command: '!Банпереводов [id/link]',
    level: 8,
  },
  {
    command: '!Разбанпереводов [id/link]',
    level: 8,
  },
  {
    command: '!Банрепорт [id/link]',
    level: 8,
  },
  {
    command: '!Разбанрепорт [id/link]',
    level: 8,
  },
  {
    command: 'Гет [id/link]',
    level: 8,
  },
  {
    command: 'Ответ [id] [текст]',
    level: 8,
  },
  {
    command: 'Обнулить [id/link]',
    level: 8,
  },
  {
    command: 'Выдатьлимит [id/link] [кол-во]',
    level: 10,
  },
  {
    command: 'Права [id/link] [null/vip/premium/moder/admin/stadmin/sponsor/owner]',
    level: 10,
  },
  {
    command: '±Промо [id/link]',
    level: 10,
  },
  {
    command: 'Сетлимит [id/link] [кол-во]',
    level: 10,
  },
  {
    command: 'Сетник [id/link] [никнейм]',
    level: 10,
  },
  {
    command: 'Сетранг [id/link] [название]',
    level: 10,
  },
  {
    command: '!Последниеигры',
    level: 10
  },
  {
    command: 'Создать промо [название] [кол-во активаций] [кол-во]',
    isDostup: true,
  },
  {
    command: 'Удалить промо [название]',
    isDostup: true
  },
  {
    command: 'Промокоды',
    level: 0,
    isDostup: true
  }
]

module.exports = {
  pattern: /^(?:кмд|админ(?:\-|\s)?команды)$/i,
  handler: (context, { bot, append }) => {
    if (context.isChat) {
      return bot(`доступ к админ-командам можно получить только в личных сообщениях @club${context.$groupId} (сообщества)`);
    }

    const { name } = utils.rightToString(context.user.rightLevel)

    return bot(`команды для привилегии "${name}"
      Параметры:
      ᅠ[] - необязательные параметры
      ᅠid - игровой ID игрока
      ᅠlink - ссылка на вк, пересланное сообщение или ответ на сообщение
      ᅠкол-во - количество
      
      ${commands
        .filter(({ level, isDostup }) => level && (context.user.rightLevel >= level) || (isDostup === context.user.promoDostup))
        .map(({ command }, index) => `${index + 1}. ${command}`)
        .join('\n')
      }
    `);
  },
  isRole: true,
  role: 3,
}