const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:забрать)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<count>(?:[0-9\.]+[kкmм]*|вс[её])))$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('игрок не найден в базе данных.');
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    const { count } = context.$match.groups;

    const formatCount = utils.parse2Int(count.replace(/вс[её]|all|в[ао]банк/i, user.balance.toString()));

    if (!formatCount) {
      return bot('укажите сумму, которую хотите выдать.');
    }

    if (user.balance < formatCount) {
      return bot(`у игрока нет столько MB.
        💵 Его баланс составляет: ${utils.sp(user.balance)} MB
      `)
    }

    user.balance -= formatCount;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ БАЛАНСА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" изъял у Вас ${utils.sp(formatCount)} MB
        💵 Ваш баланс составляет: ${utils.sp(user.balance)} MB
      `, {
        peer_id: user.vkId,
      });
    }

    await context.send(stripIndents`[ЛОГИ / ИЗМЕНЕНИЕ БАЛАНСА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" изъял у игрока "@id${user.vkId} (${user.name})" ${utils.sp(formatCount)} MB
      💵 Его баланс: ${utils.sp(user.balance)} MB
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID)
    });

    return bot(`Вы забрали у игрока "@id${user.vkId} (${user.name})" ${utils.sp(formatCount)} MB`);
  },
  isRole: true,
  role: 8
}