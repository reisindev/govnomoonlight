const { stripIndents } = require("common-tags");

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:выдать)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<count>(?:[0-9\.]+[kкmм]*|вс[её]|all|в[оа]банк)))$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context, context.senderId);

    if (!user) {
      return bot('игрок не найден в базе данных.');
    }

    if (user.vkId !== context.senderId && user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    const { count } = context.$match.groups;

    const formatCount = utils.parse2Int(count.replace(/вс[её]|all|в[ао]банк/i, context.user.give.toString()));

    if (!context.user.give) {
      return bot(`у Вас закончился лимит выдачи, лимит обновляется каждый день в 00:00 по МСК.`);
    }

    if (!formatCount) {
      return bot('укажите сумму, которую хотите выдать.');
    }

    if (context.user.give < formatCount) {
      return bot(`укажите сумму меньше или равному вашему лимиту.
        [💴] Ваш лимит: ${utils.sp(context.user.give)} MB
      `);
    }

    context.user.give -= formatCount;
    user.balance += formatCount;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.vkId !== context.senderId && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ БАЛАНСА]
        [👤] ${name} "@id${context.senderId} (${context.user.name})" выдал Вам ${utils.sp(formatCount)} MB
        [💵] Ваш баланс составляет: ${utils.sp(user.balance)} MB
      `, {
        peer_id: user.vkId
      });
    }

    await context.send(stripIndents`[ЛОГИ / ИЗМЕНЕНИЕ БАЛАНСА] 
      [👤] ${name} "@id${context.senderId} (${context.user.name})" выдал ${user.vkId === context.user.vkId ? 'себе' : `игроку @id${user.vkId} (${user.name})`} ${utils.sp(formatCount)} MB
      [💵] Его баланс: ${utils.sp(user.balance)} MB
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID),
    });

    return bot(`Вы выдали ${user.vkId == context.senderId ? 'себе' : `игроку "@id${user.vkId} (${user.name})"`} ${utils.sp(formatCount)} MB на баланс.
		  [🗂] Остаток лимита: ${utils.sp(context.user.give)} MB
	  `);
  },
  isRole: true,
  role: 4
}