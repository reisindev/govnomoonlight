const utils = require('../../utils');

module.exports = {
  pattern: /^(рейтинг админов|топ админов|атоп|админ топ)$/i,
  handler: async (context, { bot, append }, { users }) => {
    const allUsers = users.filter(user => !user.block.tops && user.rightLevel > 7).sort((a, b) => b.balance - a.balance);

    const topUsers = allUsers.slice(0, 10);
    const userIndex = allUsers.findIndex(user => user.vkId === context.senderId);

    return bot(`топ админов по балансу:
      ${topUsers
        .map(({ balance, vkId, name, settings, rightLevel }, index) => {
          const { name: right, icon } = utils.rightToString(rightLevel);

          return `${index === 9 ? '🔟' : utils.gi(index + 1)} ${rightLevel > 0 ? `[${icon} ${right}]` : ''} ${settings.mention ? `@id${vkId} (${name})` : name} — ${utils.sp(balance)} MB`
        })
        .join('\n')
      }
      —————————————————
      ${utils.gi(userIndex + 1)} ${context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name} — ${utils.sp(context.user.balance)} MB
    `);
  },
  isRole: true,
  role: 5
}