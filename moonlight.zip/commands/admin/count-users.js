module.exports = {
  pattern: /^(?:скок игроков|кол-во игроков)$/i,
  handler: async (_, { bot }, { users }) => {
    return bot(`в боте зарегистрировано ${users.length} игроков`);
  },
  isRole: true,
  role: 8,
}