const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:\!set-name|сетник)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<name>.+))?$/i,
  handler: async (context, { bot }) => {
    const { name: text } = context.$match.groups;

    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('игрок не найден в базе данных.');
    }

    const lastName = user.name;

    user.name = text ?? `Смените никнейм! #${user.gameId}`;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ НИКА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" изменил Вам никнейм на: ${user.name}
      `, {
        peer_id: user.vkId
      });
    }

    await context.send(stripIndents`[ЛОГИ / ИЗМЕНЕНИЕ НИКА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" изменил ник игроку "@id${user.vkId} (${lastName})" на: ${user.name}
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID)
    });

    return bot(`Вы изменили ник игроку "@id${user.vkId} (${lastName})" на: ${user.name}`);
  },
  isRole: true,
  role: 10
}