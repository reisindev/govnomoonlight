const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:создать)(?:\s(?<title>.+))(?:\s(?<activation>(?:[0-9\.]+[kкmм]*)))(?:\s(?<count>(?:[0-9\.]+[kкmм]*)))$/i,
  handler: async (context, { bot }, { promo }) => {
    const { title, activation, count } = context.$match.groups;

    const formatActivation = utils.parse2Int(activation);
    const formatCount = utils.parse2Int(count);

    if (!formatCount) {
      return bot('укажите сумму промокода');
    }

    if (await promo.findOne({ title })) {
      return bot(`промокод "${title}" уже находится в базе данных!`);
    }

    await (
      await promo.create({
        title,
        activation: formatActivation,
        value: formatCount
      })
    ).save();

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    await context.send(stripIndents`[ЛОГИ / СОЗДАНИЕ ПРОМОКОДА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" создал промокод на ${utils.sp(formatCount)} MB
      🎆 Количество активаций: ${utils.sp(formatActivation)} шт.
      🔥 Название промокода: ${title}
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID),
    });

    return context.send(stripIndents`
      👑 Был создан НОВЫЙ промокод на ${utils.sp(formatCount)} MB
      🎆 Кол-во активаций: ${utils.sp(formatActivation)} шт.
      🔥 Для использования, введите "Промо ${title}"
    `);
  },
  isDostup: true
}