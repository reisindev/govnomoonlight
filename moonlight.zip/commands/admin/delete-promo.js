const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:удалить промо)(?:\s(?<title>.+))$/i,
  handler: async (context, { bot }, { promo }) => {
    const { title } = context.$match.groups;

    const promocode = await promo.findOne({ title });

    if (!promocode) {
      return bot(`промокод "${title}" не найден в базе данных!`);
    }

    const { title: promoTitle } = promocode;

    await promocode.deleteOne();

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    await context.send(stripIndents`[ЛОГИ / УДАЛЕНИЕ ПРОМОКОДА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" удалил промокод "${promoTitle}"
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID),
    });

    return bot(`Вы удалили промокод "${promoTitle}"`);
  },
  isDostup: true
}