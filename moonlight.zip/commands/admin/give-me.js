const utils = require('../../utils');

module.exports = {
  pattern: /^(?:!получить)$/i,
  handler: (context, { bot }) => {
    if (context.user.timers.give > Date.now()) {
      return bot(`нельзя так часто получать валюту, попробуйте через ${utils.dateFormat(context.user.timers.give)}`);
    }

    context.user.balance += context.user.give;
    context.user.timers.give = Date.now() + 60_000 * 60;

    return bot(`Вы получили ${utils.sp(context.user.give)} MB
      💵 Ваш баланс: ${utils.sp(context.user.balance)} MB
    `);
  },
  isRole: true,
  role: 3,
}