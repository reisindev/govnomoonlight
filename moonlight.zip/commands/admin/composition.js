module.exports = {
  pattern: /^(?:состав)$/i,
  handler: async (_, { bot }, { users }) => {
    const textArray = [
      {
        level: 11,
        text: '👨‍💻 Разработчики:',
        users: []
      },
      {
        level: 10,
        text: '💠 Владельцы:',
        users: []
      },
      {
        level: 9,
        text: '🔥 Ст. администраторы:',
        users: []
      },
      {
        level: 8,
        text: '⚡ Администраторы:',
        users: []
      },
      {
        level: 7,
        text: '⭐ Модераторы:',
        users: []
      },
      {
        level: 6,
      text: '💲 Спонсоры:',
      users: []
      },
      {
        level: 5,
        text: '👥 Представители:',
        users: []
      },
      
    ];

    for await (const user of users.filter(user => user.rightLevel > 2)) {
      const text = textArray.find(({ level }) => level === user.rightLevel);

      if (!text) {
        continue;
      }

      text.users.push({
        name: user.name,
        vkId: user.vkId,
        mention: user.settings.mention,
      });
    }

    const newTextArray = textArray
      .filter((item) => item.users.length);

    return bot(`состав: 
      ${newTextArray.map((item) => `
        ${item.text && item.users.length > 1 ? item.text : item.text.replace(/[ыи]\:$/i, '')}
        ${item.users
        .map((user) => user.mention ? `@id${user.vkId} (${user.name})` : user.name)
        .join('\n')}
        `)
        .join('\n')
      }
    `);
  },
  isRole: true,
  role: 5
}