const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:выдатьлимит|give-limit)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<count>(?:[0-9\.]+[kкmм]*|вс[её])))?$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('игрок не найден в базе данных.');
    }

    if (user.vkId === context.senderId && ![849297880, 849297880, 849297880].includes(context.senderId)) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (user.rightLevel >= context.user.rightLevel && ![849297880, 849297880, 849297880].includes(context.senderId)) {
      return bot('Вы не можете выполнить данное действие на игроке, ее ранг выше Вашего.');
    }

    const { count } = context.$match.groups;

    const formatCount = utils.parse2Int((count || '5000000').replace(/вс[её]/i, '5000000'));

    if (!formatCount) {
      return bot('укажите сумму для выдачи лимита игроку');
    }

    user.limits.give += formatCount;
    user.give = user.limits.give;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ ЛИМИТА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" выдал Вам на лимит для выдачи ${utils.sp(formatCount)} MB
      `, {
        peer_id: user.vkId
      });
    }

    await context.send(stripIndents`[ЛОГИ / ИЗМЕНЕНИЕ ЛИМИТА] 
      👤 ${name} "@id${context.senderId} (${context.user.name})" выдал игроку "@id${user.vkId} (${user.name})" лимит ${utils.sp(formatCount)} MB
      🗂 Его лимит: ${utils.sp(user.limits.give)} MB
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID),
    });

    return bot(`Вы выдали игроку "@id${user.vkId} (${user.name})" лимит для выдачи ${utils.sp(formatCount)} MB`);
  },
  isRole: true,
  role: 10
}