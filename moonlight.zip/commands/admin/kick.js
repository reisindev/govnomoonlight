const { resolveResource } = require('vk-io');

const utils = require('../../utils');

async function getUser(context) {
  const { link: resource } = context.$match.groups;

  if (resource) {
    try {
      const result = await resolveResource({ api: context['api'], resource });

      const admins = await context['api'].groups.getMembers({
        filter: 'managers',
        group_id: process.env.POLLING_GROUP_ID.toString()
      });

      const adminsAndCreatorIds = admins.items.filter((item) => item.id && (item.role === 'administrator' || item.role === 'creator')).map((item) => item.id);

      if (result.id === context.senderId || result.id === context.$groupId || adminsAndCreatorIds.includes(result.id)) {
        return;
      }

      return {
        type: result.type,
        id: result.id,
        mention: result.type === 'group' ? `@club${+result.id} (Сообщество) было исключено` : `@id${result.id} (Пользователь) был исключён`
      };
    } catch (error) {
      return;
    }
  }

  const senderId = context.hasForwards ? context.forwards[0]?.senderId : context.replyMessage?.senderId;

  return {
    type: senderId < 0 ? 'group' : 'user',
    id: senderId,
    mention: senderId < 0 ? `@club${+senderId} (Сообщество) было исключено` : `@id${senderId} (Пользователь) был исключён`
  };
}

module.exports = {
  pattern: /^(?:\!?кик|\!?kick)(?:\s(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:(?:id|club|public)\d+|.+))|(?:\[(?:club|public|id)\d+\|.+\])))?/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);
    const result = await getUser(context);

    if (user && user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    if (result) {
      try {
        await context['api'].messages.removeChatUser({ member_id: result.id, chat_id: context.chatId });

        return bot(`${result.mention} из данного диалога.`);
      } catch (error) {
        if (error.code === 925) {
          return bot('выдайте мне администратора для использовании данной команды! ❌');
        } else if (error.code === 935) {
          return bot(`данного ${result.type === 'user' ? 'пользователя' : 'сообщества'} нет в данном диалоге! ❌`);
        }

        return bot(`произошла ошибка на стороне VK: ${error.toString()}`);
      }
    }
  },
  isRole: true,
  role: 5
}