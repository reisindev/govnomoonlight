const { stripIndents } = require("common-tags");

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:ответ(?:ить)?)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s\n?(?<answer>.*))$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('данного игрока нет в базе данных');
    }

    if (user.vkId === context.senderId) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (user.timers.report === null) {
      return bot('игрок не писал репорт');
    }

    if (user.report.answer) {
      return bot('игроку уже ответил другой администратор');
    }

    if (!user.is_allowed && !user.fromChat) {
      return bot(`невозможно отправить ответ @id${user.vkId} (игроку), у него не разрешена отправка сообщений от @club${context.$groupId} (сообщества).`);
    }

    const { answer } = context.$match.groups;

    await context.send(stripIndents`
      ➡ @id${user.vkId} (${user.name}), Поступил ответ на Ваш репорт
      💬 Ответ: ${answer}
      🆘 Ответил: @id${context.senderId} (${context.user.name})
    `, {
      peer_id: user.fromReport,
      forward: JSON.stringify({
        peer_id: user.fromReport,
        conversation_message_ids: [user.fromCMID],
        is_reply: true
      })
    });

    user.timers.report = null;
    user.fromCMD = null;
    user.fromChat = null;
    user.fromReport = null;

    return bot(`ответ отправлен.`);
  },
  isRole: true,
  role: 8
}