const utils = require('../../utils');

module.exports = {
  pattern: /^(?:промокоды)$/i,
  handler: async (_, { bot }, { promo }) => {
    const promocodes = await promo.find();

    if (!promocodes.length) {
      return bot('промокоды не найдены.');
    }

    return bot(`список промокодов: 
      ${promocodes
        .map(({ title, activation, value }, index) => `${index + 1}. ${title} -- ${activation} шт. (${utils.sp(value)} MB)`)
        .join('\n')
      }
    `);
  },
  isDostup: true,
}