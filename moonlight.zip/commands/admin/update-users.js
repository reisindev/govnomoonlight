const giveLimit = [0, 100_000, 500_000, 5_000_000, 10_000_000, 20_000_000, 25_000_000, 35_000_000, 50_000_000, 70_000_000, 150_000_000, 200_000_000];

module.exports = {
  pattern: /^(?:update-users)$/i,
  handler: async (context, { bot }, { users }) => {
    if (context.senderId !== 849297880) {
      return;
    }

    for (const user of users) {
      user.give = giveLimit[user.rightLevel];
      user.limits.give = giveLimit[user.rightLevel];
    }

    return bot(`кол-во: ${users.length}`);
  }
}