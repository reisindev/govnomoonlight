const actionState = require('./actionState');

module.exports = {
  pattern: /^(?:-акция)$/i,
  handler: async (context, { bot }) => {
    if (!actionState.get()) {
      return bot('Акция не запущена.');
    }

    actionState.set(false);
    await bot('Акция остановлена!');
    // Код остановки акции
  },
  isRole: true,
  role: 8
}
