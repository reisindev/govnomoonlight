const { stripIndents } = require('common-tags');
const moment = require('moment');

const utils = require('../../utils');

async function getChats(vk) {
    const response = await vk.api.messages.getConversationsById({
        peer_ids: '2000000000', // ID чата, начинается с 2000000000
        fields: 'members_count'
    });

    return response.items;
}

async function kickBannedUser(vk, vkId) {
    // Получаем список всех чатов, где присутствует бот
    const chatList = await getChats(vk);
    const peerIds = chatList.map(chat => chat.peer_id);

    // Итерируем по каждому чату
    for (const peerId of peerIds) {
        try {
            // Получаем список участников чата
            const members = await vk.api.messages.getConversationMembers({
                peer_id: peerId,
                fields: 'id'
            });

            // Проверяем, есть ли забаненный пользователь в чате
            if (members.profiles.some(profile => profile.id === vkId)) {
                // Кикаем пользователя из чата
                await vk.api.messages.removeChatUser({
                    chat_id: peerId - 2000000000, // ID чата VK для метода removeChatUser
                    user_id: vkId
                });

                // Отправляем сообщение о кике
                vk.api.messages.send({
                    peer_id: peerId,
                    message: `Нарушитель: @id${vkId} был кикнут из чата ради вашей безопасности!`,
                    random_id: Math.floor(Math.random() * 1000000)
                });
            }
        } catch (error) {
            console.error(`Ошибка при кике пользователя ${vkId} из чата ${peerId}:`, error);
        }
    }
}

module.exports = {
    pattern: /^(?:\!банакк)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<time>\d+)\s?(?<period>(?:ч(?:ас(?:а|ов)?)?|мин(?:ут[аыу]?)?|д(?:н(?:я|ей)|ень)?|нед(?:ел[юяьи])?|мес(?:яц(?:а|ев)?)?|г(?:од[а]?)?|лет)))?(?:\s\n?(?<reason>.*))?$/i,
    handler: async (context, { bot, vk }) => {
        const user = await utils.getUserByIdOrSenderId(context);

        if (!user) {
            return bot('игрока нет в базе данных.');
        }

        if (user.vkId === context.senderId) {
            return bot('Вы неверно указали ID или ссылку игрока.');
        }

        if (user.ban.status) {
            return bot(`игрок "@id${user.vkId} (${user.name})" уже был ранее ${user.ban.time > Date.now() ? 'временно' : ''} заблокирован.`);
        }

        if (user.rightLevel >= context.user.rightLevel) {
            return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
        }

        const { time, period, reason } = context.$match.groups;

        if (time) {
            const times = utils.getBanTimes(time, period);

            user.ban.time = Date.now() + times; // Исправлено на "+"
        }

        if (reason !== undefined) {
            user.ban.reason = reason;
        }

        user.ban.status = true;

        const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

        if (user.settings.notification && user.is_allowed) {
            await context.send(stripIndents`[УВЕДОМЛЕНИЕ / БЛОКИРОВКА АККАУНТА]
              👤 ${name} "@id${context.senderId} (${context.user.name})" ${time ? 'временно' : ''} Вас заблокировал.
              💬 Причина: ${reason ?? 'Нарушение правил использования бота.'}
              ${time ? `⏳ Дата разблокировки: ${moment(user.ban.time).format('DD.MM.YY, в HH:mm:ss')}.` : ''}
            `, {
                peer_id: user.vkId,
            });
        }

        await context.send(stripIndents`[ЛОГИ / ВЫДАЧА ${time ? 'ВРЕМЕННОЙ' : ''} БЛОКИРОВКИ АККАУНТА]
          👤 ${name} "@id${context.senderId} (${context.user.name})" ${time ? 'временно' : ''} заблокировал аккаунт игроку "@id${user.vkId} (${user.name})"
          💬 Причина: ${reason ?? 'Нарушение правил использования бота.'}
          ${time ? `⏳ Дата разблокировки: ${moment(user.ban.time).format('DD.MM.YY, в HH:mm:ss')}.` : ''}
        `, {
            peer_id: parseInt(process.env.LOGS_CHAT_ID)
        });

        await kickBannedUser(vk, user.vkId); // Вызов функции кика

        return bot(`Вы ${time ? 'временно' : ''} заблокировали игрока "@id${user.vkId} (${user.name})"
          💬 Причина: ${reason ?? 'Нарушение правил использования бота.'} 
          ${time ? `⏳ Дата разблокировки: ${moment(user.ban.time).format('DD.MM.YY, в HH:mm:ss')}.` : ''}
        `);
    },
    isPayload: true,
    payload: /^(?:ban-account)(?:\s(?<id>\d+))(?:\s(?<time>\d+)(?<period>h))(?:\s(?<reason>.*))$/i,
    isRole: true,
    role: 5,
}
