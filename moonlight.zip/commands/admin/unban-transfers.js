const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:\!разбан\s?переводов)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('данного игрока нет в базе данных.');
    }

    if (user.vkId === context.senderId) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (!user.block.transfers) {
      return bot(`у игрока "@id${user.vkId} (${user.name})" не заблокированы переводы.`);
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    user.block.transfers = false;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / РАЗБЛОКИРОВКА ПЕРЕВОДОВ]
        👤 ${name} "@id${context.senderId} (${context.user.name})" разблокировал Вам возможность переводить валюту игрокам.
      `, {
        peer_id: user.vkId,
      });
    }

    await context.send(stripIndents`[ЛОГИ / РАЗБЛОКИРОВКА АККАУНТА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" разблокировал возможность переводить валюту игроку "@id${user.vkId} (${user.name})"
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID)
    });

    return bot(`Вы разблокировали переводы игроку "@id${user.vkId} (${user.name})"`);
  },
  isRole: true,
  role: 8,
}