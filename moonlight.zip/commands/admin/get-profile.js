const moment = require('moment');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:гет)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?$/i,
  handler: async (context, { bot, append }, { vk }) => {
    const user = await utils.getUserByIdOrSenderId(context, context.user.vkId, context.user.gameId);

    if (!user) {
      return bot('игрока нет в базе данных')
    }

    const { icon, name } = utils.rightToString(user.rightLevel, user.rightCustomName);

    append(`🆔 ID: ${user.gameId}`);
    append(`${icon} Ранг: ${name}`);
    append(`💵 Баланс: ${utils.sp(user.balance)} MB`);

    if (user.vkId !== context.user.vkId) {
      append(`⛔ Игрок ${user.ban.status ? 'заблокирован' : 'не заблокирован'}`);

      if (user.ban.time > Date.now()) {
        append(`ᅠ❌ Снятие блокировки через ${utils.dateFormat(user.ban.time)}`);
      }

      if (user.ban.reason) {
        append(`ᅠ💬 Причина блокировки: ${user.ban.reason}`);
      }
    }

    append(`💲 Последняя ставка: ${utils.sp(user.lastBet)} MB`);
    append(`🗂 Лимит: ${utils.sp(user.give)} MB`);
    append('');
    append(`⌚ Последняя активность: ${moment(user.activity).format('HH:mm:ss, DD.MM.YYYY')}`);

    if (user.createdAt) {
      append(`📅 Дата регистрации: ${moment(user.createdAt).format('HH:mm:ss, DD.MM.YYYY')}`);
    }

    if (user.timers.give > Date.now()) {
      append(`⌚ До обнуления лимита осталось ${utils.dateFormat(user.timers.give)}`);
    }
    
    const [{ photo_max }] = await vk.api.users.get({ user_ids: [user.vkId], fields: "photo_max" })

    

    const photo = await vk.upload.messagePhoto({
        source: {
            value: photo_max
        }
    })

    return bot(`${user.vkId === context.user.vkId ? 'Ваша подробная статистика' : `информация об игроке @id${user.vkId} (${user.name})`}: ${context.$text}`, { attachment: photo.toString() });
  },
  isRole: true,
  role: 8,
  isPayload: true,
  payload: /^(?:get-account)(?:\s(?<id>\d+))$/i,
}