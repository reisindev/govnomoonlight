const utils = require('../../utils');

module.exports = {
  pattern: /^(?:\!last-games|\!последние\s?игры)$/i,
  handler: async (context, { bot }) => {
    if (!context.isChat || !context.chat.double) {
      return bot('команда доступна только в чате.');
    }

    const user = await utils.getMemberConversation(context);

    if (!user.is_admin && !user.is_owner) {
      return bot('Вы не можете посмотреть статистику игр в данном чате, это могут сделать только администраторы и/или создатель беседы!');
    }

    const lastGames = context.chat.games.sort((a, b) => b.time - a.time).filter((game) => !game.status && game.users.length).splice(0, 10).reverse()
    const factors = [];

    for (const game of lastGames) {
      for (const user of game.users) {
        if (user.factor === 2) {
          factors.push({
            factor: 2,
            count: game.users.filter(user => user.factor === 2).length,
            hash: game.hash,
          });
        }

        if (user.factor === 3) {
          factors.push({
            factor: 3,
            count: game.users.filter(user => user.factor === 3).length,
            hash: game.hash,
          });
        }

        if (user.factor === 5) {
          factors.push({
            factor: 5,
            count: game.users.filter(user => user.factor === 5).length,
            hash: game.hash,
          });
        }

        if (user.factor === 10) {
          factors.push({
            factor: 10,
            count: game.users.filter(user => user.factor === 10).length,
            hash: game.hash,
          });
        }

        if (user.factor === 50) {
          factors.push({
            factor: 50,
            count: game.users.filter(user => user.factor === 50).length,
            hash: game.hash,
          });
        }
      }
    }

    if (!lastGames.length) {
      return bot('игры в чате ещё не были сформированы. Подождите некоторое время...');
    }

    return bot(`последние игры:
      ${lastGames
        .map((game, index) => `
          ${index === 9 ? '🔟' : utils.gi(index + 1)}. Выпал коэффициент x${game.factor}
  
          🏆 Количество ставок: ${game.users.length} шт.
          🥇 Количество победных ставок: ${game.users.filter((user) => user.factor === game.factor).length} шт.
          🎰 Большинство игроков ставили на коэффициент: х${factors.filter((factor) => factor.hash === game.hash).sort((a, b) => b.count - a.count)[0].factor}
  
          🎲 Хеш игры: ${game.hash}
          ✅ Проверка честности: ${game.originalHash}
        `)
        .join('\n')
      }
    `);
  },
  isRole: true,
  role: 10
}