const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:\!разбанакк)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('данного игрока нет в базе данных.');
    }

    if (user.vkId === context.senderId) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (!user.ban.status) {
      return bot(`игрок "@id${user.vkId} (${user.name})" не заблокирован`);
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    if (user.ban.time !== null) {
      user.ban.time = null;
    }

    user.ban.status = false;
    user.ban.reason = null;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / РАЗБЛОКИРОВКА АККАУНТА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" разблокировал Вам аккаунт.
      `, {
        peer_id: user.vkId,
      });
    }

    await context.send(stripIndents`[ЛОГИ / РАЗБЛОКИРОВКА АККАУНТА]
      👤 ${name} "@id${context.senderId} (${context.user.name})" разблокировал аккаунт игроку "@id${user.vkId} (${user.name})"
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID)
    });

    return bot(`Вы разблокировали игрока "@id${user.vkId} (${user.name})"`);
  },
  isPayload: true,
  payload: /^(?:unban-account)(?:\s(?<id>\d+))$/i,
  isRole: true,
  role: 8
}