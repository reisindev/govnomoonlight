const { stripIndents } = require('common-tags');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:обнулить)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('игрок не найден в базе данных.');
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    user.balance = 100;

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ БАЛАНСА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" обнулил Вам баланс до ${utils.sp(user.balance)} MB
      `, {
        peer_id: user.vkId
      });
    }

    return bot(`Вы обнулили баланс до ${utils.sp(user.balance)} MB игроку "@id${user.vkId} (${user.name})"`);
  },
  isRole: true,
  role: 8
}