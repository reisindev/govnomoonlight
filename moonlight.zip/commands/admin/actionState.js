let isActionActive = false;

module.exports = {
  get: () => isActionActive,
  set: (state) => isActionActive = state
}
