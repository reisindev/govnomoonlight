
const { resolveResource } = require('vk-io');

module.exports = {
  pattern: /^(?:\!?кик_собак|\!?kicks_dogs)$/i,
  handler: async (context, { bot }) => {
    try {
      // Fetch the list of chat members
      const chatMembers = await context.api.messages.getConversationMembers({
        peer_id: 2000000000 + context.chatId,
      });

      // Filter out deleted (blocked) users
      const deletedUsers = chatMembers.profiles.filter((profile) => profile.deactivated === 'deleted');

      if (deletedUsers.length === 0) {
        return bot('В беседе нет заблокированных (удалённых) пользователей.');
      }

      // Attempt to remove each deleted user
      for (const user of deletedUsers) {
        try {
          await context.api.messages.removeChatUser({
            member_id: user.id,
            chat_id: context.chatId,
          });

          await bot(`@id${user.id} (Пользователь) был исключён из беседы.`);
        } catch (error) {
          if (error.code === 925) {
            return bot('Выдайте мне администратора для выполнения данной команды! ❌');
          } else if (error.code === 935) {
            await bot(`Пользователь @id${user.id} уже не находится в беседе. ❌`);
          } else {
            await bot(`Произошла ошибка при удалении пользователя @id${user.id}: ${error.toString()}`);
          }
        }
      }
    } catch (error) {
      return bot(`Произошла ошибка при выполнении команды: ${error.toString()}`);
    }
  },
  isRole: true,
  role: 5,
};