const { stripIndents } = require('common-tags');

const utils = require('../../utils');

const rightLevelToString = {
  0: 'Игрок',
  1: 'VIP',
  2: 'PREMIUM',
  3: 'Легенда',
  4: 'Ultra',
  5: 'Perfoment',
  6: 'Спонсор',
  7: 'Модератор',
  8: 'Администратор',
  9: 'Ст. Администратор',
  10: 'Владелец',
  11: 'Разработчик'
}

const limitsGive = [0, 0, 0, 2_000_000, 2_500_000, 3_500_000, 6_000_000, 500_000_000, 500_000_000, 1_000_000_000, 500_000_000_000];
const limitsName = [15, 20, 25, 35, 40, 45, 50, 50, 50, 70, 100];

module.exports = {
  pattern: /^(?:права)(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<type>(?:null|vip|prem(?:ium)?|leg|ultra|perf|moder|adm(?:in)?|st(?:\.|\s)?adm(?:in)?)|sponsor|owner))$/i,
  handler: async (context, { bot }) => {
    const user = await utils.getUserByIdOrSenderId(context);

    if (!user) {
      return bot('игрок не найден в базе данных');
    }

    if (user.vkId === context.senderId) {
      return bot('Вы неверно указали ID или ссылку игрока.');
    }

    if (user.rightLevel >= context.user.rightLevel) {
      return bot('Вы не можете выполнить данное действие на игроке, его ранг выше или равен Вашему.');
    }

    const { type } = context.$match.groups;

    const rightLevel = parseInt(type.replace('null', '0').replace('vip', '1').replace(/^prem(ium)?/i, '2').replace('leg', '3').replace('ultra', '4').replace('perf', '5').replace(/^moder/i, '7').replace(/^adm(?:in)?/i, '8').replace(/^st(\.|\s)?adm(in)?/i, '9').replace('sponsor', '6').replace(/owner/i, '10'));

    if (rightLevel > context.user.rightLevel) {
      return bot('Вы не можете выдать игроку роль Выше своей.');
    }

    user.rightLevel = rightLevel;
    user.limits.give = limitsGive[rightLevel];
    user.give = user.limits.give;
    user.limits.name = limitsName[rightLevel];

    const { name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ИЗМЕНЕНИЕ РАНГА]
        👤 ${name} "@id${context.senderId} (${context.user.name})" выдал Вам ранг "${rightLevelToString[user.rightLevel]}"
      `, {
        peer_id: user.vkId,
      });
    }

    await context.send(stripIndents`[ЛОГИ / ИЗМЕНЕНИЕ РАНГА] 
      👤 ${name} "@id${context.senderId} (${context.user.name})" выдал игроку "@id${user.vkId} (${user.name})" ранг "${rightLevelToString[user.rightLevel]}"
    `, {
      peer_id: parseInt(process.env.LOGS_CHAT_ID),
    });

    return bot(`Вы выдали игроку "@id${user.vkId} (${user.name})" ранг "${rightLevelToString[rightLevel]}"`);
  },
  isRole: true,
  role: 4
}