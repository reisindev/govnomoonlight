module.exports = {
  ...require('./admin'),
  ...require('./common'),
  ...require('./conversations'),
  ...require('./group'),
  ...require('./private')
}