const utils = require('../../utils');

module.exports = {
  pattern: /.*/,
  handler: async (context, { bot }, { vk }) => {
    const links = [];

    const { items } = await vk.api.messages.getConversationsById({
      peer_ids: [2000000002, 2000000043],
      group_id: context.$groupId,
    });

    for (const { peer, chat_settings } of items) {
      const { link } = await vk.api.messages.getInviteLink({
        peer_id: peer.id,
        group_id: context.$groupId,
      });

      links.push({
        title: chat_settings.title,
        link
      });
    }

    return bot(`чтобы начать играть Достаточно перейти по одной из ссылок в беседу

      ✅ Список официальных бесед бота:
      ${links.map(({ title, link }, index) => `${utils.gi(index + 1)} ${title} - ${link}`).join('\n\n')}
    `);
  },
  isPrivate: true,
  isPayload: false,
}
