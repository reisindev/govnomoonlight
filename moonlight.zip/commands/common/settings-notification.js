module.exports = {
  pattern: /^(?:уведы)(?:\s(?<type>(?:вкл|выкл)))$/i,
  handler: async (context, { bot }) => {
    const { type } = context.$match.groups;

    const isOn = /вкл|on/i.test(type);

    if (isOn && context.user.settings.notification) {
      return bot('у Вас уже включены уведомления!')
    } else if (/выкл|off/i.test(type) && !context.user.settings.notification) {
      return bot('у Вас уже выключены уведомления!')
    }

    context.user.settings.notification = isOn;

    return bot(`Вы ${isOn ? 'включили' : 'отключили'} уведомления!`);
  },
  isPayload: true,
  payload: /^(?:notification)(?:\s(?<type>(?:off|on)))$/i,
}