const utils = require('../../utils');

module.exports = {
  pattern: /^(рейтинг|топ)$/i,
  handler: async (context, { bot, append }, { users }) => {
    const allUsers = users.filter(user => !user.block.tops && user.rightLevel < 8).sort((a, b) => b.balance - a.balance);

    const topUsers = allUsers.slice(0, 10);

    if (!context.user.block.tops && context.user.rightLevel < 8) {
      const userIndex = allUsers.findIndex(user => user.vkId === context.senderId);

      append('—————————————————');
      append(`${utils.gi(userIndex + 1)} ${context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name} — ${utils.sp(context.user.balance)} MB`);
    }

    return bot(`топ игроков по балансу:
      ${topUsers
        .map(({ balance, vkId, name, settings, rightLevel }, index) => {
          const { name: right, icon } = utils.rightToString(rightLevel);

          return `${index === 9 ? '🔟' : utils.gi(index + 1)} ${rightLevel > 0 ? `[${icon} ${right}]` : ''} ${settings.mention ? `@id${vkId} (${name})` : name} — ${utils.sp(balance)} MB`
        })
        .join('\n')
      } ${context.$text}
    `);
  },
  isPayload: true,
  payload: /^(?:ratings)$/i,
}