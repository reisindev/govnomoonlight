const { Keyboard } = require('vk-io');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:п[еи]р[еи](?:да(?:ть|й)|в(?:ести|од)))(?:\s(?<id>\d+)?(?<link>(?:http?s:\/\/vk\.(?:ru|com)\/(?:id\d+|\w+))|(?:\[id\d+\|@?\w+\]))?)?(?:\s(?<value>(?:[0-9\.]+[kкmм]*|вс[её])))$/i,
  handler: async (context, { bot }) => {
    if (context.user.block.transfers) {
      return bot('Вам заблокирован доступ к переводам.');
    }

    if (context.user.rightLevel > 7) {
      return bot('Вы не можете совершать переводы между игроками.');
    }

    const user = await utils.getUserByIdOrSenderId(context);

    if (!user || user.rightLevel > 3) {
      return bot('Вы указали неправильную ссылку.');
    }

    const { value } = context.$match.groups;

    const formatCount = utils.parse2Int(value.replace(/вс[её]/i, context.user.balance));

    if (!formatCount) {
      return bot('укажите сумму не ниже нуля.');
    }

    if (formatCount > context.user.balance) {
      return bot('у Вас недостаточно средств на балансе.');
    }

    context.user.transfer = false;

    return bot(`Вы зашли в мобильный банк:
      👤 Получатель: @id${user.vkId} (${user.name})
      💵 Сумма платежа: ${utils.sp(formatCount)} MB

      ❓ Уверены совершить перевод указанной суммы на счёт игрока?
    `, {
      keyboard: Keyboard.builder()
        .textButton({
          label: '💵 Перевести',
          payload: `transfer-${context.user.vkId} ${user.vkId} ${formatCount}`,
          color: 'positive'
        })
        .inline()
    });
  }
}