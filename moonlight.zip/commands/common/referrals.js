const utils = require('../../utils');

module.exports = {
  pattern: /^(?:рефералы)$/i,
  handler: async (context, { bot }, { users }) => {
    const allReferrals = users.sort((a, b) => b.referrals.length - a.referrals.length);
    const userIndex = allReferrals.findIndex(user => user.vkId === context.senderId);
    const topReferrals = allReferrals.limit(10);

    if (!topReferrals.length) {
      return bot('топ рефералов ещё не сформировался, повторите попытку позже!');
    }

    return bot(`топ рефералов:
      ${topReferrals.map(({ vkId, name, referrals, settings }, index) => `${index === 9 ? '🔟' : utils.gi(index + 1)} ${settings.mention ? `@id${vkId} (${name})` : name} — ${utils.sp(referrals.length)} реф.`).join('\n')}
      —————————————————
      ${utils.gi(userIndex + 1)} ${context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name} — ${utils.sp(context.user.referrals.length)} рефералов.
    `);
  }
}