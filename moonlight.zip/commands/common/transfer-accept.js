const { stripIndents } = require('common-tags');
const { Keyboard } = require('vk-io');

const utils = require('../../utils');

module.exports = {
  payload: /^(?:transfer-(?<senderId>\d+))(?:\s(?<userId>\d+))(?:\s(?<count>\d+))$/i,
  handler: async (context, { bot }, { users }) => {
    const { senderId, userId, count } = context.$match.groups;

    if (parseInt(senderId) !== context.user.vkId) {
      return;
    }

    const user = users.find(user => user.vkId === parseInt(userId));

    if (!user || context.user.transfer) {
      return;
    }

    await bot('создаём транзакцию...');
    await utils.sleep(1_500);

    user.balance += parseInt(count);

    context.user.balance -= parseInt(count);
    context.user.transfer = true;

    const { name, icon } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    if (user.settings.notification && user.is_allowed) {
      await context.send(stripIndents`[УВЕДОМЛЕНИЕ / ПЕРЕВОД ВАЛЮТЫ]
        🏦 @id${user.vkId} (${user.name}), новый перевод! 📢
        ${icon} ${name} "@id${context.senderId} (${context.user.name})" отправил Вам ${utils.sp(count)} MB
        🔕 Нажмите кнопку ниже, если не хотите получать подобные сообщения
      `, {
        peer_id: user.vkId,
        keyboard: Keyboard.builder()
          .textButton({
            label: '🔕 Отключить уведомления',
            payload: 'notification off',
            color: 'negative'
          })
          .inline()
      });
    }

    return bot(`Вы перевели игроку "@id${user.vkId} (${user.name})" ${utils.sp(count)} MB
      💵 Баланс: ${utils.sp(context.user.balance)} MB
    `);
  },
  isPayload: true,
}