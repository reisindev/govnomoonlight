const utils = require('../../utils');



module.exports = {
  pattern: /^(игротоп)$/i,
  handler: async (context, { bot, append }, { users }) => {
    const allUsers = users.filter(user => !user.block.tops && user.rightLevel < 8).sort((a, b) => b.lastBet - a.lastBet);

    const topUsers = allUsers.slice(0, 10);

    if (!context.user.block.tops && context.user.rightLevel < 0) {
      const userIndex = allUsers.findIndex(user => user.vkId === context.senderId);

      append('—————————————————');
      append(`${utils.gi(userIndex + 1)} ${context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name} — ${utils.sp(context.user.lastBet)} MB`);
    }

    return bot(`топ игроков по последним ставкам:
      ${topUsers
        .map(({ lastBet, vkId, name, settings, rightLevel }, index) => {
          const { name: right, icon } = utils.rightToString(rightLevel);

          return `${index === 9 ? '🔟' : utils.gi(index + 1)} ${rightLevel > 0 ? `[${icon} ${right}]` : ''} ${settings.mention ? `@id${vkId} (${name})` : name} — ${utils.sp(lastBet)} MB`
        })
        .join('\n')
      } ${context.$text}
    `);
  },
  isRole: true,

  role: 0

}