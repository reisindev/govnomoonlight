const { Keyboard } = require('vk-io');

const keyboard = Keyboard.builder()
  .textButton({ label: '💰 Банк', payload: 'bank', color: 'positive' })
  .textButton({ label: '📂 Профиль', payload: 'profile', color: 'positive' })
  .textButton({ label: '💵 Баланс', payload: 'balance', color: 'positive' })
  .row()
  
  .textButton({ label: '👑 Рейтинг', payload: 'ratings', color: 'positive' })
  .textButton({ label: '🎈 Донат', payload: 'donate', color: 'positive' })
  .row()
  
  .textButton({ label: '🎁 Бонус', payload: 'bonus', color: 'positive' })
  .textButton({ label: '🎁 Подарок', payload: 'gift', color: 'positive' })
  .row()
  
  .textButton({ label: '2⃣ x2', payload: 'bet 2', color: 'negative' })
  .textButton({ label: '3⃣ x3', payload: 'bet 3', color: 'negative' })
  .textButton({ label: '5⃣ x5', payload: 'bet 5', color: 'negative' })
  .row()
  .textButton({ label: '🔯 x10', payload: 'bet 10', color: 'negative' })
  .textButton({ label: '🔯 x50', payload: 'bet 50', color: 'negative' })
  .oneTime(false);

module.exports = {
  pattern: /^(?:меню|кнопки)$/i,
  handler: async (_, { bot }) => {
    return bot('обновляю клавиатуру...', {
      keyboard
    });
  }
}
