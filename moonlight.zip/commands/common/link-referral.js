module.exports = {
  pattern: /^(?:реф(?:ерал(?:ка)?)?)$/i,
  handler: async (context, { bot }, { vk }) => {
    const url = `https://vk.com/write-${context.$groupId}?ref=${context.senderId}`;
    const { short_url } = await vk.api.utils.getShortLink({ url });

    return bot(`приглашайте друзей с помощью реферальной ссылки.
      🎯 Если друг активирует Вашу реферальную ссылку, Вы получите +100 MB при получении бонуса к себе на аккаунт, Ваш же друг получит только +50 MB при получении бонуса

      📌 Ваша реферальная ссылка: ${short_url}
    `);
  }
}