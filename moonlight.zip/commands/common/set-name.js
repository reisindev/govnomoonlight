const utils = require('../../utils');

module.exports = {
  pattern: /^(?:ник)(?:\s(?<type>(?:вкл|выкл)))?(?:\s(?<name>.+))?$/i,
  handler: async (context, { bot }) => {
    const { type, name } = context.$match.groups;

    if (type) {
      if (/выкл/i.test(type) && !context.user.settings.mention) {
        return bot('у Вас уже отключена гиперссылка.');
      }

      if (/вкл/i.test(type) && context.user.settings.mention) {
        return bot('у Вас уже включена гиперссылка.');
      }

      const isOn = /вкл/i.test(type);

      context.user.settings.mention = isOn;

      return bot(`Вы ${isOn ? 'включили' : 'отключили'} гиперссылку.`);
    }

    if (!name && !type) {
      return bot(`использование: "ник [название]"
        💵 Стоимость: 100.000 MB
      `);
    }

    if (context.user.balance < 10_000) {
      return bot('для смены ника вам нужно 10.000 MB 💸');
    }

    if (name.length > context.user.limits.name) {
      return bot('Вы указали длинный ник.');
    }

    if (name.length < 4) {
      return bot('Вы указали короткий ник.');
    }

    context.user.balance -= 10_000;
    context.user.name = name.replace(/(vto\.pe|ep\.otv)/ig, '*');

    return bot(`${utils.getRandomElement([
      'фантастический ник',
      'крутой ник',
      'классный ник',
      'прикольный ник',
      'красивый ник',
      'таких ников я ещё не видел',
    ])} ${utils.getRandomElement(['😯', '🙂', '☺'])}`);
  }
}