const moment = require('moment');
const utils = require('../../utils');
const request = require('request');

module.exports = {
  pattern: /^(?:проф(?:иль)?)$/i,
  handler: async (context, { bot, append }, { vk }) => {
    const { icon, name } = utils.rightToString(context.user.rightLevel, context.user.rightCustomName);

    append(`⏩ Ник: ${context.user.name}`);
    append(`🆔 ID: ${context.user.gameId}`);
    append(`${icon} Ранг: ${name}`);
    append(`💵 Баланс: ${utils.sp(context.user.balance)} MB`);
    append(`💲 Последняя ставка: ${utils.sp(context.user.lastBet)} MB`);
    append(`🗂 Лимит: ${utils.sp(context.user.give)} MB`);
    append('');
    
    const [{ photo_max }] = await vk.api.users.get({ user_ids: [context.user.vkId], fields: "photo_max" })
    
    const photo = await vk.upload.messagePhoto({
        source: {
            value: photo_max
        }
    })
    
    return bot(`Ваш профиль: ${context.$text}`, { attachment: photo.toString() });
  },
  isPayload: true,
  payload: /^(?:profile)$/i,
};