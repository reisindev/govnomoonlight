const utils = require('../../utils');

module.exports = {
  pattern: /^(?:баланс)$/i,
  handler: (context, { bot }) => {

    return bot(`Ваш баланс: ${utils.sp(context.user.balance)} MB 💸`);
  },
  isPayload: true,
  payload: /^(?:balance)$/i,
}