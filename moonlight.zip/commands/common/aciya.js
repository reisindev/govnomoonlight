module.exports = {
  pattern: /^(?:беседа проверка)$/i,
  handler: async (context, { bot }) => {
    try {
      if (!context.vk?.api) {
        return bot('❌ Ошибка инициализации VK API');
      }

      if (!context.isChat) {
        return bot('❗ Команда работает только в беседах!');
      }

      const { profiles, groups, items } = await context.vk.api.messages.getConversationMembers({
        peer_id: context.peerId,
        group_id: context.$groupId
      });

      if (!items.some(item => item.is_owner && item.member_id === context.senderId)) {
        return bot('❌ Только создатель беседы может запустить проверку!');
      }

      if (profiles.length < 100) {
        return bot('❌ Требуется минимум 100 участников!');
      }

      if (groups.length > 3) {
        return bot('❌ Максимум 3 сообщества/бота!');
      }

      await bot('🔍 Проверка началась...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      return context.send({
        message: `✅ Проверка пройдена! Создатель: @id${context.senderId}`,
        peer_id: 2 // ID админ-чата
      });

    } catch (error) {
      console.error('Ошибка:', error);
      return bot('⚠ Ошибка сервера!');
    }
  }
}
