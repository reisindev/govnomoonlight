const { Keyboard } = require('vk-io');

const emptyKeyboard = Keyboard.builder().oneTime(false);

module.exports = {
  pattern: /^(?:скрыть|убрать кнопки)$/i,
  handler: async (_, { bot }) => {
    return bot('скрываю клавиатуру...', {
      keyboard: emptyKeyboard
    });
  }
}
