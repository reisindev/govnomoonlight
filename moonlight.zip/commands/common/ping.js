const ANSWER = {
  "зай": 'люблю',
  "пинг": 'ПОНГ',
  "мур": 'МЯУ',
}

module.exports = {
  pattern: /^(?:зай|пинг|мур)$/i,
  handler: (context, { bot }, { time }) => {
    const received = Date.now() - context.createdAt * 1000;

    return bot(`${ANSWER[context.$match[0].toLowerCase()]}
      ⌚ Получено через ${received >= 1000 ? `${(received / 1000).toFixed(2)} sec.` : `${received} ms.`} 
			🕐 Обработано за ${Date.now() - time} ms.
    `);
  }
}