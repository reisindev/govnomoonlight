const { stripIndents } = require('common-tags');
const { Keyboard } = require('vk-io');

const utils = require('../../utils');

module.exports = {
  pattern: /^(?:реп(?:орт)?)(?:\s(.*))$/i,
  handler: async (context, { bot }) => {
    if (context.user.rightLevel > 3) {
      return bot('к сожалению Вы не можете отправить репорт, Вы администратор и должны отвечать на репорты других игроков.');
    }

    if (context.user.block.reports) {
      return bot('у Вас стоит блокировка репортов.');
    }

    if (context.user.timers.report > Date.now()) {
      return bot(`репорт можно писать только ОДИН раз в 30 минут! 🔥
        ❗ Подождите ещё ${utils.dateFormat(context.user.timers.report)}
      `);
    }

    const randomMinutes = utils.getRandomInt(5, 60);

    await context.send(stripIndents`
      Поступила новая жалоба от игрока: @id${context.user.vkId} (${context.user.name})

      🆔 ID: ${context.user.gameId}
      ${context.isChat ? `▶ В беседе №${context.chatId}` : '<enter>'}
    
      📝 Для ответа введите "Ответ ${context.user.gameId} [ваше сообщение, без скобок]"
      📖 Подробная информация: "Гет ${context.user.gameId}"
    `.replace('<enter>\n', ''), {
      peer_id: parseInt(process.env.ADMIN_CHAT_ID),
      attachment: context.getAttachments(['photo']),
      forward: JSON.stringify({
        peer_id: context.peerId,
        conversation_message_ids: [context.conversationMessageId],
      }),
      keyboard: Keyboard.builder()
        .textButton({
          label: '🆘 Заблокировать репорт',
          payload: `ban-report ${context.user.gameId}`,
          color: 'secondary'
        })
        .row()
        .textButton({
          label: '⛔ Заблокировать на 24 часа',
          payload: `ban-account ${context.user.gameId} 24h Оффтоп.`,
          color: 'secondary'
        })
        .row()
        .textButton({
          label: '📕 Проверить профиль',
          payload: `get-account ${context.user.gameId}`,
          color: 'secondary'
        })
        .inline()
    });

    context.user.timers.report = Date.now() + 60_000 * 30;
    context.user.report.answer = false;
    context.user.fromChat = context.isChat;
    context.user.fromReport = context.peerId;
    context.user.fromCMID = context.conversationMessageId;

    return bot(`Ваше обращение отправлено.
      📮 Примерное время ожидания ответа ${randomMinutes} минут
    `);
  }
}