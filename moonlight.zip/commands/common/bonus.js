const utils = require('../../utils');

const rightBonusBalance = [100, 500, 700, 25_000, 30_000, 40_000, 60_000, 65_000, 85_000, 105_000, 120_000, 200_000];

module.exports = {
  pattern: /^(?:бонус)$/i,
  handler: async (context, { bot }) => {
    if (context.user.timers.bonus > Date.now()) {
      return bot(`до получения бонуса подождите ещё ${utils.dateFormat(context.user.timers.bonus)}`);
    }

    const balance = rightBonusBalance[context.user.rightLevel] + context.user.referralBonus;

    context.user.balance += balance;
    context.user.timers.bonus = Date.now() + 60_000 * 10;

    if ([0, 10].includes(context.user.rightLevel)) {
      return bot(`Вы получили бонус +${utils.sp(balance)} MB
        💵 Ваш баланс: ${utils.sp(context.user.balance)} MB

        🎁 Следующий бонус будет доступен через ${utils.dateFormat(context.user.timers.bonus)}
      `);
    } else if (context.user.rightLevel === 11) {
      return bot(`Вы получили бонус разработчика +${utils.sp(balance)} MB
        💵 Ваш баланс: ${utils.sp(context.user.balance)} MB

        🎁 Следующий бонус будет доступен через 10 минут.
		Спасибо вам за то что вы развиваете нашего бота <3
      `);
    }

    const { name, icon } = utils.rightToString(context.user.rightLevel);

    return bot(`Вы получили бонус +${utils.sp(balance)} MB
      ${icon} Ваш бонус был увеличен за счёт ранга - ${name}
      💵 Ваш баланс: ${utils.sp(context.user.balance)} MB

      🎁 Следующий бонус будет доступен через 10 минут.
    `);
  },
  isPayload: true,
  payload: /^(?:bonus)$/i,
}