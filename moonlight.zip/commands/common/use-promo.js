const utils = require('../../utils');

module.exports = {
  pattern: /^(?:промо)(?:\s(?<title>.*))$/i,
  handler: async (context, { bot }, { promo }) => {
    const { title } = context.$match.groups;

    const promoInfo = await promo.findOne({ title });

    if (!promoInfo) {
      return bot('промокод не найден или его не существует');
    }

    if (!promoInfo.activation) {
      return bot('у данного промокода закончились активации');
    }

    if (promoInfo.users.includes(context.senderId)) {
      return bot('Вы уже использовали данный промокод');
    }

    promoInfo.users.push(context.senderId);

    await promoInfo.$inc('activation', -1).save();

    context.user.balance += promoInfo.value;

    return bot(`Муууур
    Вы успешно активировали промокод под названием "${promoInfo.title}"
      💰 Получено: ${utils.sp(promoInfo.value)} MB
      💵 Баланс: ${utils.sp(context.user.balance)} MB
      📏 Осталось активаций: ${utils.sp(promoInfo.activation)} шт.
    `);
  }
}