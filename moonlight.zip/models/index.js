const posts = require('./post');
const promo = require('./promo');

module.exports = {
  posts,
  promo
}