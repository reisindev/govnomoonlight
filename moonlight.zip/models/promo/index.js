const { Schema, model } = require('mongoose');

const promoSchema = new Schema({
  title: {
    required: true,
    type: 'string',
    unique: true,
  },
  activation: {
    type: 'number',
    required: true,
  },
  value: {
    type: 'number',
    required: true
  },
  users: {
    type: ['number'],
    default: []
  }
}, {
  versionKey: false
});

module.exports = model('promos', promoSchema, 'promocodes');