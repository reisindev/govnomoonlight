const { Schema, model } = require('mongoose');

const postSchema = new Schema({
  postId: {
    type: 'number',
    required: true,
  },
  likers: {
    type: [Number],
    default: [],
  }
}, {
  versionKey: false
});

module.exports = model('posts', postSchema, 'posts');