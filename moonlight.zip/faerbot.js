require('dotenv/config');

const { writeFile } = require('fs/promises');
const { resolve } = require('path');

const { random } = require('chance-percent');
const md5 = require('md5');
const { stripIndents } = require('common-tags');
const { Interval } = require('@rus-anonym/scheduler');
const { VK, getRandomId } = require('vk-io');
const mongoose = require('mongoose');

const moduleCommands = require('./commands');
const utils = require('./utils');
const { posts, promo } = require('./models');

const chats = require('./json/chats.json');
const users = require('./json/users.json');

const vk = new VK({
	token: process.env.TOKEN,
	pollingGroupId: process.env.POLLING_GROUP_ID,
	apiLimit: process.env.API_LIMIT,
	apiMode: process.env.API_MODE,
	apiVersion: process.env.API_VERSION
});

const commands = [];

const attachments = [
	{
		factor: 2,
		value: 'photo-219531381_457243316'
	},
	{
		factor: 3,
		value: 'photo-219531381_457243317'
	},
	{
		factor: 5,
		value: 'photo-219531381_457243318'
	},
	{
		factor: 10,
		value: 'photo-219531381_457243319'
	},
	{
		factor: 50,
		value: 'photo-219531381_457243320'
	},
]

const baseFactors = [
	{
		value: 2,
		percentage: 50,
	},
	{
		value: 3,
		percentage: 35,
	},
	{
		value: 5,
		percentage: 5,
	},
	{
		value: 10,
		percentage: 5,
	},
	{
		value: 50,
		percentage: 5
	}
];

const giveLimit = [0, 0, 0, 0, 0, 0, 0, 35_000_000, 50_000_000, 70_000_000, 150_000_000];

function saveChats() {
	return writeFile(resolve('json', 'chats.json'), JSON.stringify(chats, null, '\t'), 'utf-8');
}

function saveUsers() {
	return writeFile(resolve('json', 'users.json'), JSON.stringify(users, null, '\t'), 'utf-8');
}

vk.updates.use(async (context, next) => {
	try {
		if (context.is(['message_new']) && context.isUser) {

			context.user = users.find(user => user.vkId === context.senderId);
			context.chat = chats.find((chat) => chat.peerId === context.peerId);

			context.$text = '\n';
		}

		return next();
	} catch (error) {
		console.error('MiddlewareError:', error);
	}
});

vk.updates.on('message_subscription', async (context, next) => {
	const user = users.find(user => user.vkId === context.userId);

	if (user) {
		user.is_allowed = context.isSubscribed;
	}

	await saveUsers();

	return next();
});

vk.updates.on('like_add', async (like, next) => {
	if (like.objectType !== 'post') {
		return next();
	}

	const user = users.find(user => user.vkId === like.likerId);
	const post = await posts.findOne({ postId: like.objectId });

	if (!user) {
		return next();
	}

	const attachment = `wall-${like.$groupId}_${like.objectId}`;
	const link = `https://vk.com/club${like.$groupId}?w=wall-${like.$groupId}_${like.objectId}`;

	if (post) {
		if (post.likers.includes(user.vkId)) {
			return next();
		}

		post.likers.push(user.vkId);
		await post.save();

	} else {
		await (
			await posts.create({
				postId: like.objectId,
				likers: [user.vkId]
			})
		).save();
	}

	if (!post || !post.likers.includes(user.vkId)) {
		user.balance += 100;

		if (user.is_allowed) {
			await vk.api.messages.send({
				peer_id: user.vkId,
				message: `✅ За лайк [${link}|данного] поста вы получили 100 MB`,
				random_id: getRandomId(),
				attachment,
			});
		}
	}

	await saveUsers();

	return next();
});

vk.updates.on('message_new', async (context, next) => {
    if (context.isChat && !context.chat) {
        chats.push({
            peerId: context.peerId,
            games: [],
            game: false,
            double: false,
            code: null,
            timers: {
                gift: null,
                game: 60,
            },
            start: false,
            lastGameId: 0,
        });

        await saveChats();

        context.chat = chats.find((chat) => chat.peerId === context.peerId);
    }

    return next();
});


async function kickBannedUser(vkId) {
    const chatList = chats.map(chat => chat.peerId);

    for (const peerId of chatList) {
        try {
            const members = await vk.api.messages.getConversationMembers({
                peer_id: peerId,
                fields: 'id'
            });

            if (members.profiles.some(profile => profile.id === vkId)) {
                await vk.api.messages.removeChatUser({
                    chat_id: peerId - 2000000000,
                    user_id: vkId
                });

                vk.api.messages.send({
                    peer_id: peerId,
                    message: `Нарушитель: @id${vkId} был кикнут из чата ради вашей безопасности!`,
                    random_id: Math.floor(Math.random() * 1000000)
                });
            }
        } catch (error) {
            console.error(`Ошибка при кике пользователя ${vkId} из чата ${peerId}:`, error);
        }
    }
}

vk.updates.on('message_new', async (context, next) => {
    if (!context.user && context.isUser) {
        const [{ first_name }] = await vk.api.users.get({ user_ids: [context.senderId] });

        const { is_allowed } = await vk.api.messages.isMessagesFromGroupAllowed({
            user_id: context.senderId,
            group_id: context.$groupId,
        });

        users.push({
            gameId: users.length + 1,
            vkId: context.senderId,
            name: first_name,
            referral: context.referralValue !== undefined && parseInt(context.referralValue) !== context.senderId,
            referralBonus: 0,
            referrals: [],
            balance: 100,
            timers: {
                bonus: null,
                report: null,
                give: null,
            },
            settings: {
                mention: true,
                mailing: true,
                notification: true,
            },
            rightLevel: 0,
            rightCustomName: null,
            lastBet: 0,
            ban: {
                status: false,
                reason: null,
                time: null
            },
            block: {
                reports: false,
                tops: false,
                transfers: false
            },
            report: {
                answer: false
            },
            give: 100_000,
            limits: {
                give: 100_000,
                name: 15,
            },
            transfer: false,
            activity: new Date(),
            is_allowed,
            promoDostup: false,
            fromReport: null,
            fromCMID: null,
            fromChat: null
        });

        context.user = users.find(user => user.vkId === context.senderId);

        await saveUsers();

        vk.api.messages.send({
            peer_id: context.senderId,
            message: `
            🌙 Привет! Я Moonlight Bot, ваш новый компаньон в играх и приключениях Double режима! 🎉

            Меня создала талантливая девушка: @yarusovi (Gerl Dev), и я здесь, чтобы сделать ваш опыт более интересным! 😄

            Чтобы начать играть, пожалуйста, добавьте меня в чат и дайте права администратора. Затем напишите команду "дабл создать", чтобы запустить игру! 🚀

            Жду вас в играх! 🎮
            Есть еще один игровой бот: @mistikbot, будет время - залетай и туда!
            `,
            random_id: Math.floor(Math.random() * 1000000)
        });
    }

    if (context.user && context.user.ban.status) {
        if (context.isChat) {
            await kickBannedUser(context.senderId);
            return context.send(stripIndents`
                Нарушитель: @id${context.senderId} был кикнут из чата ради вашей безопасности!`);
        } else {
            return context.send(stripIndents`
                ${context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name}, Ваш аккаунт заблокирован. ⛔
            `);
        }
    }

    return next();
});


vk.updates.on('message_new', async (context, next) => {
	const command = commands.find((command) => command.isPayload && context.hasMessagePayload
		? command.payload?.test(context.messagePayload)
		: command.pattern?.test(context.text?.replace(/^\//i, '').replace(/\[club\d+\|.+\]\s/i, ''))
	);

	if (command) {
		const time = Date.now();

		function bot(text, params) {
			const mention = context.user.settings.mention ? `@id${context.senderId} (${context.user.name})` : context.user.name;

			return context.send(stripIndents`${mention}, ${text}`, params);
		}

		if (command.isRole && command.role > context.user.rightLevel) {
			return bot('Вы не можете использовать данную команду.');
		}

		if (command.isDostup && !context.user.promoDostup) {
			return;
		}

		if (command.isPrivate && context.isChat) {
			return;
		}

		function append(text = '') {
			context.$text += `${text}\n`;
		}

		context.$match = command.isPayload && context.hasMessagePayload
			? command.payload?.exec(context.messagePayload)
			: command.pattern?.exec(context.text?.replace(/^\//i, '').replace(/\[club\d+\|.+\]\s/i, ''));

		await command.handler(context, { bot, append }, { vk, users, promo, chats, time });
	}

	context.user.activity = new Date();

	await saveChats();
	await saveUsers();

	return next();
});

Object.values(moduleCommands).forEach((command) => commands.push(command));

async function startVKLongPoll() {
  try {
    await vk.updates.start();
    console.log('[VKAPI] LongPoll has been started!');
  } catch (error) {
    console.error('[VKAPI] Error starting LongPoll:', error);
  }
}

async function connectToMongoDB() {
  try {
    await mongoose.set('strictQuery', false).connect(process.env.MONGO_URI);
    console.log('[MongoDB] Local database has been connected!');
  } catch (error) {
    console.error('[MongoDB] Error connecting to database:', error);
  }
}

Promise.all([
  startVKLongPoll(),
  connectToMongoDB()
]);


setInterval(async () => {
	for (const chat of chats.filter((chat) => chat.double)) {
		if (chat.games.length !== 0 && chat.games[chat.lastGameId].users.length) {
			chat.timers.game -= 1;
		}

		if (chat.timers.game === 5 && chat.games[chat.lastGameId].bet) {
			chat.games[chat.lastGameId].bet = false;

			await vk.api.messages.send({
				message: '🎇 До конца раунда осталось менее пяти секунд, ставки не принимаются',
				random_id: getRandomId(),
				peer_id: chat.peerId,
			});
		}

		if (chat.timers.game === 1 && !chat.games[chat.lastGameId].bet) {
			await vk.api.messages.send({
				message: '💡 Итак, результаты раунда...',
				random_id: getRandomId(),
				peer_id: chat.peerId,
			});
		}
if (chat.timers.game === 0 && chat.start) {
			chat.start = false;
			chat.game = false;

			const wins = chat.games[chat.lastGameId].users.sort((a, b) => a.factor - b.factor);

			let text = '';

			const { factor, hash, originalHash } = chat.games[chat.lastGameId];

			for (const win of wins) {
				const user = users.find(user => user.vkId === win.vkId);

				if (win.factor === factor) {
					text += `
						✅ ${win.mention ? `@id${win.vkId} (${win.name})` : win.name} ставка - ${utils.sp(win.balance)} SB на x${win.factor} выиграла!
						💵 Приз составляет: ${utils.sp(win.balance * win.factor)} SB\n
					`;

					user.balance += Math.floor(win.balance * win.factor);
				} else {
					text += `❌ ${win.mention ? `@id${win.vkId} (${win.name})` : win.name} ставка - ${utils.sp(win.balance)} SB на x${win.factor} проиграла\n`;
				}
			}

			const attachment = attachments.find((item) => item.factor === factor).value;

			await vk.api.messages.send({
				peer_id: chat.peerId,
				message: stripIndents`
						🔱 Выпал коэффициент – x${factor} 

						${text}

						🎮 Хеш игры: ${hash}
						▶ Проверка честности: ${originalHash}					
				`,
				attachment,
				random_id: getRandomId(),
				dont_parse_links: true,
			});

			await saveUsers();
		}
		

		if (!chat.game && !chat.start) {
			chat.timers.game = 60;
			chat.game = true;
			chat.start = true;

			const factor = random(baseFactors);
			const originalHash = [`x${factor}`, utils.getRandomHax(5)].join(':');
			const hash = md5(originalHash);

			chat.games.push({
				factor,
				originalHash,
				hash,
				users: [],
				bet: true
			});

			const { items } = await vk.api.messages.getConversationsById({ group_id: parseInt(process.env.POLLING_GROUP_ID), peer_ids: [chat.peerId] });

			await vk.api.messages.send({
				peer_id: parseInt(process.env.LOGS_CHAT_ID),
				message: stripIndents`✅ Выпадет коэффициент x${factor} в чате > ${items[0].chat_settings.title}`,
				random_id: getRandomId(),
			});

			if (chat.games.length > 4) {
				chat.games = chat.games.slice(chat.games.length - 4, chat.games.length);
			}

			chat.lastGameId = chat.games.length - 1;
		}
	}
}, 1_000);

setInterval(async () => {
	for (const user of users.filter(user => user.rightLevel > 2)) {
		if (user.timers.give < Date.now()) {
			user.give = user.limits.give;
		}
	}

	await saveUsers();
}, 1_000);

new Interval({
	cron: '00 00 * * *',
	source: async () => {
		for (const user of users.filter((user) => user.rightLevel < 3)) {
			user.give = user.limits.give;
		}

		await saveUsers();
	},
	onError: console.error
});