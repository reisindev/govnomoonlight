/* 
  # THE CODE'S AUTHOR AND DEVELOPER @n1k1ta_romanov
*/

require('moment-precise-range-plugin');

const { randomBytes } = require('node:crypto');

const moment = require('moment');
const { resolveResource } = require('vk-io');

const users = require('./json/users.json');

const defaultNumber = Number('100000000000000');

const rightLevelToIcon = {
  0: '👤',
  1: '🔥',
  2: '⚡',
  3: '⭐',
  4: '💫',
  5: '🎀',
  6: '🌠',
  7: '💥',
  8: '❤',
  9: '🎇',
  10: '💠',
  11: '👨‍💻'
}

const rightLevelToString = {
  0: 'Игрок',
  1: 'VIP',
  2: 'PREMIUM',
  3: 'LEGEND',
  4: 'ULTRA',
  5: 'PERFOMENT',
  6: 'Спонсор',
  7: 'Модератор',
  8: 'Администратор',
  9: 'Ст. администратор',
  10: 'Владелец',
  11: 'Разработчик'
}

const units = [
  {
    value: 1,
    symbols: '',
  },
  {
    value: 1e3,
    symbols: ' тыс.',
  },
  {
    value: 1e6,
    symbols: ' млн.',
  },
  {
    value: 1e9,
    symbols: ' млрд.',
  },
  {
    value: 1e12,
    symbols: ' трлн.',
  },
  {
    value: 1e15,
    symbols: ' квадрлн.',
  },
  {
    value: 1e18,
    symbols: ' квинтлн.',
  },
];

function getRandomInt(min, max) {
  return max ? Math.round(Math.random() * (max - min)) + min : Math.round(Math.random() * min);
}

function getRandomElement(array = []) {
  return array[getRandomInt(array.length - 1)];
}

function sp(value) {
  const string = Number(value).toLocaleString();
  const separator = getSeparator(string);

  return string.split(separator).join('.');
}

function gi(value) {
  let string = '';
  const stringInt = String(value).toString();

  for (let i = 0; i < stringInt.length; i++) {
    string += `${stringInt[i]}&#8419;`;
  }

  return string;
}

function dateFormat(unix) {
  const output = [];
  const { days, hours, minutes, seconds } = moment.preciseDiff(moment(), moment(unix), true);

  if (days) {
    output.push(`${days} д.`);
  }

  if (hours) {
    output.push(`${hours} ч.`);
  }

  if (minutes) {
    output.push(`${minutes} мин.`);
  }

  if (seconds) {
    output.push(`${addZero(seconds)} сек.`);
  }

  return output.join(', ');
}

function getRandomHax(size = 18) {
  return randomBytes(size).toString('hex')
}

function parse2Int(int) {
  const string = (typeof int === 'number' ? int : int).toString();

  const $num = string.replace(/([0-9\.]+)([kкmм]+)/gi, (_, num, replacer) => {
    const $num = Number(num);

    if (!replacer) {
      return $num.toString();
    }

    const zeros = replacer.replace(/[kк]/gi, '000').replace(/[mм]/gi, '000000');
    const replaced = `1${zeros}`;

    const result = Number(num) * Number(replaced);

    if (result > defaultNumber) {
      return defaultNumber.toString();
    }

    return result.toString();
  });

  const number = parseInt($num, 10);

  return isNaN(number) ? 0 : number;
}

function getBanTimes(time, period) {
  if (/(ч(ас(а|ов)?)?|h(ours?)?)/i.test(period)) {
    return 60_000 * 60 * time;
  }

  if (/(мин(ут(а|ы|у)?)?|min(utes?)?)/i.test(period)) {
    return 60_000 * time;
  }

  if (/(д((н(я|ей))?|ень)?|d(ays?)?)/i.test(period)) {
    return 60_000 * 60 * 24 * time;
  }

  if (/(нед(ел(ю|я|ь|b))?|w(eeks?)?)/i.test(period)) {
    return 60_000 * 60 * 24 * 7 * time;
  }

  if (/(мес(яц(а|ев)?)?|m(onths?)?)/i.test(period)) {
    return 60_000 * 60 * 24 * moment().daysInMonth() * time;
  }

  if (/(г(од(а)?)?|лет|y(ears?)?)/i.test(period)) {
    return 60_000 * 60 * 24 * moment().daysInMonth() * 12 * time
  }

  return 1_000 * time;
}

async function getUserByIdOrSenderId(context, vkId) {
  const { id, link } = context.$match.groups;

  if (parseInt(id)) {
    return users.find((_, index) => index === parseInt(id) - 1);
  }

  if (link) {
    try {
      const result = await resolveResource({
        api: context['api'],
        resource: link
      });

      if (result.type !== 'user' || result.id === context.senderId) {
        return;
      }

      return users.find(user => user.vkId === result.id);
    } catch (error) {
      return;
    }
  }

  const user = users.find(user => user.vkId === (context.hasForwards ? context.forwards[0]?.senderId : context.replyMessage?.senderId ?? vkId));

  if (user?.vkId !== context.senderId && !vkId) {
    return user;
  }

  return user;
}

async function sleep(ms) {
  return new Promise((resolve) => setInterval(resolve, ms))
}

async function getMemberConversation(context) {
  const { items } = await context['api'].messages.getConversationMembers({
    peer_id: context.peerId,
    group_id: context.$groupId,
  });

  return items?.find((user) => user.member_id === context.senderId);
}

function getSeparator(value) {
  if (/,/i.test(value)) {
    return ',';
  }

  if (/\s/i.test(value)) {
    return /\s/;
  }

  return '.'
}

function addZero(int) {
  return int < 11 ? `0${int}` : int.toString();
}

function rightToString(id, name) {
  return {
    icon: rightLevelToIcon[id],
    name: name ?? rightLevelToString[id]
  };
}

function rn(number, decPlaces = 0) {
  const isNegative = number < 0;
  const abbreviatedNumber = Math.trunc(number);

  if (abbreviatedNumber === null || abbreviatedNumber === 0) {
    return number.toString();
  }

  const tier = units.filter(({ value }) => abbreviatedNumber >= value).pop();

  if (!tier) {
    return abbreviatedNumber.toFixed(decPlaces);
  }

  const [numberFixed] = (abbreviatedNumber / tier.value).toFixed(decPlaces).split('.0');

  return `${isNegative ? '-' + abbreviatedNumber : abbreviatedNumber}${tier.symbols}`;
}

module.exports = {
  sp,
  getRandomElement,
  getRandomInt,
  gi,
  dateFormat,
  getRandomHax,
  parse2Int,
  getBanTimes,
  getUserByIdOrSenderId,
  sleep,
  getMemberConversation,
  rightToString,
  rn
}

/* 
  # THE CODE'S AUTHOR AND DEVELOPER @n1k1ta_romanov
*/